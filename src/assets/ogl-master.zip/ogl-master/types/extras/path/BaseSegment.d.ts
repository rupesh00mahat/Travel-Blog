/**
 * Abstract base class for path segments.
 * This class contains common methods for all segments types.
 */
export default class BaseSegment {}
