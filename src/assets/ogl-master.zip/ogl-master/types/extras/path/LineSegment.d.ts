import BaseSegment from './BaseSegment.js';

export default class LineSegment extends BaseSegment {}
