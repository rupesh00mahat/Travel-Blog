import BaseSegment from './BaseSegment.js';

export default class QuadraticBezierSegment extends BaseSegment {}
