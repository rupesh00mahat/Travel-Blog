import BaseSegment from './BaseSegment.js';

export default class CubicBezierSegment extends BaseSegment {}
